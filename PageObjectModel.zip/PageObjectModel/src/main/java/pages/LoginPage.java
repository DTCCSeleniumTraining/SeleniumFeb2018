package pages;

import wrappers.LeafTapsWrappers;

public class LoginPage extends LeafTapsWrappers {
	
	public LoginPage enterUserName(String data){
		enterById("username", data);
		return this;
	}
	
	public LoginPage enterPassword(String data){
		enterById("password", data);
		return this;
	}
	
	public HomePage clickLogin(){
		clickByClassName("decorativeSubmit");
		return new HomePage();
	}
	
	
	public LoginPage clickLoginForFailure(){
		clickByClassName("decorativeSubmit");		
		return this;
	}
	
	
	public LoginPage verifyErrorMessage(String text){
		verifyTextContainsById("errorDiv", text);
		return this;
	}
	
	
	
	

}
