package pages;

import wrappers.LeafTapsWrappers;

public class HomePage extends LeafTapsWrappers {
	
	public HomePage verifyLoginName(String text){
		verifyTextContainsByXpath("//h2[text()[contains(.,'Demo')]]", text);
		return this;
	}	
	
	public LoginPage clickLogOut(){
		clickByClassName("decorativeSubmit");
		return new LoginPage();
	}
}
