package steps;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.remote.RemoteWebDriver;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	public static RemoteWebDriver driver;
	@Given("Open Chrome Browser")
	public void openBrowser() {
		System.setProperty("webdriver.chrome.driver", "./drivers/chromedriver.exe");
		driver = new ChromeDriver();
	}	
	
	@And("Load the URL")
	public void loadURL() {
		driver.get("http://leaftaps.com/opentaps");
	}
	
	@And("Set timeouts")
	public void setTimeOut() {
		driver.manage().timeouts().implicitlyWait(30, TimeUnit.SECONDS);
	}
	
	@And("Maximize the window")
	public void maximizeWindow() {
		driver.manage().window().maximize();
	}
	
	@And("Enter the username as (.*)")
	public void enterUserName(String uName) {
		driver.findElementById("username").sendKeys(uName);
	}	
	
	@And("Enter the password")
	public void enterPassword() {
		driver.findElementById("password").sendKeys("crmsfa");
	}
	
	@When("Click Submit")
	public void clickLogin() {
		driver.findElementByClassName("decorativeSubmit").click();
	}
	@Then("Login should be successful")
	public void verify() {
		System.out.println("Login successfuly");
	}
	

}
